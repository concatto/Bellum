Bellum v0.0.1

Necess�rio rodar a JVM com o argumento -Djava.library.path=native. A pasta "native" deve estar no diret�rio atual.

Controles:
A: Mover para a esquerda
D: Mover para a direita
Barra de espa�o: ativar escudo (manter pressionada)
Bot�o esquerdo do mouse: atirar canh�o (carreg�vel mantendo o bot�o pressionado)
Bot�o direito do mouse: atirar arma simples